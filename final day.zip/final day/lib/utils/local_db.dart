import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_operations/models/notes.dart';

//Singleton
class LocalDB {
  LocalDB._();
  static final LocalDB instance = LocalDB._();

  static Database? _database;
  Future<Database> get database async => _database ??= await _initDB();

  // Future<Database> get database async {
  //   if (_database != null) return _database!;
  //   _database = await _initDB();
  //   return database;
  // }

  Future<Database> _initDB() async {
    //database path,
    final dbPath = await getDatabasesPath();
    final dbName = "notes.db";
    //database name,
    final path = join(dbPath, dbName);
    //await deleteDatabase(path);

    // open the database
    Database database = await openDatabase(
      path,
      version: 1,
      onCreate: (Database db, int version) async {
        // When creating the db, create the table
        await db.execute("""
            CREATE TABLE notes (
            id INTEGER PRIMARY KEY, 
            title TEXT, 
            description TEXT, 
            isRead INTEGER, 
            createdDate TEXT)
             """);
      },
    );
    return database;
  }

  Future<Note> create(Note note) async {
    final db = await instance.database;
    final id = await db.insert("notes", note.toMap());
    return note.copyWith(id: id);
  }

  Future<List<Note>> read() async {
    final db = await instance.database;
    final data = await db.query("notes", orderBy: 'title');
    List<Note> notes = data.isNotEmpty
        ? data.map((singleItem) => Note.fromMap(singleItem)).toList()
        : [];
    return notes;
  }

  Future<void> delete(int id) async {
    final db = await instance.database;
    await db.delete(
      "notes",
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> update(Note note) async {
    final db = await instance.database;

    await db.update(
      'notes',
      note.toMap(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<void> close() async {
    final db = await instance.database;
    await db.close();
  }
}

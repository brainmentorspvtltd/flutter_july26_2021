import 'package:flutter/material.dart';

class ThemeBuilder extends StatefulWidget {
  const ThemeBuilder({Key? key, required this.themeMode, required this.builder})
      : super(key: key);
  final ThemeMode themeMode;
  final Widget Function(BuildContext context, ThemeMode themeMode) builder;

  @override
  _ThemeBuilderState createState() => _ThemeBuilderState();

  static _ThemeBuilderState? of(BuildContext context) {
    return context.findAncestorStateOfType<_ThemeBuilderState>();
  }
}

class _ThemeBuilderState extends State<ThemeBuilder> {
  late ThemeMode _themeMode;

  @override
  void initState() {
    _themeMode = widget.themeMode;
    super.initState();
    // Whether this State object is currently in a tree.
    // After creating a State object and before calling initState, the framework "mounts"
    // the State object by associating it with a BuildContext.
    // The State object remains mounted until the framework calls dispose,
    // after which time the framework will never ask the State object to build again.
    // It is an error to call setState unless mounted is true.
    if (mounted) {
      setState(() {});
    }
  }

  void changeTheme() {
    setState(() {
      _themeMode =
          _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    });
  }

  ThemeMode getCurrentThemeMode() {
    return _themeMode;
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(context, _themeMode);
  }
}

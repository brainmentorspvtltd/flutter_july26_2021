//Note model class

class Note {
  final int? id;
  final String title;
  final String description;
  final bool isRead;
  final String createdDate;

  Note({
    this.id,
    required this.title,
    required this.description,
    this.isRead = false,
    required this.createdDate,
  });

  copyWith({
    int? id,
    String? title,
    String? description,
    bool? isRead,
    String? createdDate,
  }) {
    return Note(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      isRead: isRead ?? this.isRead,
      createdDate: createdDate ?? this.createdDate,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "title": title,
      "description": description,
      "isRead": isRead ? 1 : 0,
      "createdDate": createdDate,
    };
  }

  // fromJson(); when intract with api calls
  // fromMap(); when intract with local database
  // formDocument(); when intract with firebase

  factory Note.fromMap(Map<String, dynamic> data) {
    return Note(
      id: data['id'],
      title: data['title'],
      description: data['description'],
      isRead: data['isRead'] == 1 ? true : false,
      createdDate: data['createdDate'],
    );
  }
}

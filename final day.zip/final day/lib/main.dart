import 'package:flutter/material.dart';

import 'screens/my_app.dart';

//entry point to start our app
void main() {
  //runApp function used to create root widget
  runApp(MyApp());
}

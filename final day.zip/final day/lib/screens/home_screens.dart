import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sqflite_operations/models/notes.dart';
import 'package:sqflite_operations/utils/local_db.dart';
import 'package:sqflite_operations/utils/theme_builder.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text("Home Screen"),
        actions: [
          IconButton(
            onPressed: () async {
              await Navigator.of(context).pushNamed("/add-note-screen");
              setState(() {});
            },
            icon: Icon(Icons.add),
          ),
          IconButton(
            onPressed: () async {
              ThemeBuilder.of(context)?.changeTheme();
            },
            icon: Icon(Icons.brightness_4),
          ),
        ],
      ),
      body: FutureBuilder<List<Note>>(
        future: LocalDB.instance.read(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            final List<Note> notes = snapshot.data;

            return notes.isNotEmpty
                ? ListView.builder(
                    itemCount: notes.length,
                    itemBuilder: (context, index) {
                      String formattedDate = DateFormat.yMMMMd()
                          .format(DateTime.parse(notes[index].createdDate));

                      return Container(
                        //color: Theme.of(context).primaryColorLight,
                        child: ListTile(
                          onTap: () async {
                            await Navigator.of(context).pushNamed(
                                "/note-detail-screen",
                                arguments: notes[index]);
                            setState(() {});
                          },
                          title: Text(
                            "${notes[index].title}",
                            style: TextStyle(
                              fontWeight: notes[index].isRead
                                  ? FontWeight.normal
                                  : FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            formattedDate,
                            style: Theme.of(context).textTheme.bodyText2,
                          ),
                        ),
                      );
                    },
                  )
                : Center(
                    child: Text("No Data available!!"),
                  );
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}

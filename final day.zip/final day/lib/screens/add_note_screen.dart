import 'package:flutter/material.dart';
import 'package:sqflite_operations/models/notes.dart';
import 'package:sqflite_operations/utils/local_db.dart';

final LocalDB localDB = LocalDB.instance;

class AddNoteScreen extends StatefulWidget {
  const AddNoteScreen({Key? key}) : super(key: key);

  @override
  _AddNoteScreenState createState() => _AddNoteScreenState();
}

class _AddNoteScreenState extends State<AddNoteScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _desController = TextEditingController();
  bool isLoading = false;

  FocusNode _titleFocusNode = FocusNode();
  FocusNode _desFocusNode = FocusNode();
  FocusNode _submitFocusNode = FocusNode();

  @override
  void dispose() {
    _titleController.dispose();
    _desController.dispose();
    _titleFocusNode.dispose();
    _desFocusNode.dispose();
    _submitFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add New Note"),
      ),
      body: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: ListView(
            children: [
              TextFormField(
                controller: _titleController,
                focusNode: _titleFocusNode,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                    labelText: "Title",
                    isDense: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(50))),
                validator: (String? value) {
                  if (value == null && value!.isEmpty) {
                    return "Please Enter Title";
                  }
                },
                onFieldSubmitted: (term) {
                  _titleFocusNode.unfocus();
                  FocusScope.of(context).requestFocus(_desFocusNode);
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: _desController,
                focusNode: _desFocusNode,
                textInputAction: TextInputAction.done,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: "Description",
                  isDense: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                ),
                onFieldSubmitted: (term) {
                  _desFocusNode.unfocus();
                  FocusScope.of(context).requestFocus(_submitFocusNode);
                },
              ),
              SizedBox(height: 30),
              OutlinedButton(
                focusNode: _submitFocusNode,
                onPressed: isLoading ? null : _submit,
                child: Text(isLoading ? "Please Wait" : "Add Note"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _submit() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });
      final note = Note(
        title: _titleController.text.trim(),
        description: _desController.text.trim(),
        createdDate: DateTime.now().toIso8601String(),
      );

      await Future.delayed(Duration(seconds: 3));

      final addedNote = await localDB.create(note);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              "Note with title ${addedNote.title} and id ${addedNote.id} added successfully!!"),
        ),
      );

      setState(() {
        isLoading = false;
      });
      Navigator.of(context).pop();
    }
  }
}

//stf
//stl

import 'package:flutter/material.dart';
import 'package:sqflite_operations/models/notes.dart';

import 'add_note_screen.dart';
import 'home_screens.dart';
import 'note_detail_screen.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case "/":
        return MaterialPageRoute(
          builder: (context) => HomeScreen(),
        );
      case "/add-note-screen":
        return MaterialPageRoute(
          builder: (context) => AddNoteScreen(),
        );

      case "/note-detail-screen":
        final args = settings.arguments;
        return MaterialPageRoute(
          builder: (context) => NoteDetailScreen(
            note: args as Note,
          ),
        );

      default:
        return _errorHandlingRoute();
    }
  }

  static Route<dynamic> _errorHandlingRoute() {
    return MaterialPageRoute(builder: (context) {
      return Scaffold(
        appBar: AppBar(
          title: Text("Error Page"),
        ),
        body: Center(
          child: Text("Error: Opps Something Went Wrong"),
        ),
      );
    });
  }
}

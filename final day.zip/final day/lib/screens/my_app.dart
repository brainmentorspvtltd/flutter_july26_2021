import 'package:flutter/material.dart';
import 'package:sqflite_operations/screens/route_generator.dart';
import 'package:sqflite_operations/utils/theme_builder.dart';

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ThemeBuilder(
      themeMode: ThemeMode.light,
      builder: (BuildContext context, ThemeMode themeMode) {
        return MaterialApp(
          title: 'Flutter Demo',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            brightness: Brightness.light,
            primarySwatch: Colors.green,
            //scaffoldBackgroundColor: Colors.greenAccent,
          ),
          darkTheme: ThemeData(
              brightness: Brightness.dark,
              primaryColor: Colors.red,
              textTheme: TextTheme(
                  bodyText2: TextStyle(
                color: Colors.yellow,
                fontWeight: FontWeight.bold,
              ))),
          themeMode: themeMode,
          onGenerateRoute: RouteGenerator.generateRoute,
        );
      },
    );
  }
}

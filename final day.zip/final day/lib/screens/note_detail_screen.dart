import 'package:flutter/material.dart';
import 'package:sqflite_operations/models/notes.dart';
import 'package:sqflite_operations/utils/local_db.dart';

final LocalDB localDB = LocalDB.instance;

class NoteDetailScreen extends StatefulWidget {
  const NoteDetailScreen({Key? key, required this.note}) : super(key: key);
  final Note note;

  @override
  _NoteDetailScreenState createState() => _NoteDetailScreenState();
}

class _NoteDetailScreenState extends State<NoteDetailScreen> {
  @override
  void initState() {
    updateStatusOfIsRead();
    super.initState();
  }

  updateStatusOfIsRead() async {
    final note = widget.note.copyWith(isRead: true);
    await localDB.update(note);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Note Detail"),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.edit),
          ),
          IconButton(
            onPressed: () {
              localDB.delete(widget.note.id!);
              Navigator.of(context).pop();
            },
            icon: Icon(Icons.delete),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: ListView(
            children: [
              SizedBox(height: 20),
              Text(
                "${widget.note.title}",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text("${widget.note.description}"),
            ],
          ),
        ),
      ),
    );
  }
}

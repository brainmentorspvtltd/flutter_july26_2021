package com.skillrisers.sqflite_operations;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

import 'package:flutter/material.dart';
import 'package:flutter_learning/screens/add_product_screen.dart';
import 'package:flutter_learning/screens/product_detail_screen.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/product_model.dart';
import 'bottom_sheet_example.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> products = [];
  List<Map<String, dynamic>> products2 = [];

  //add product method
  addProduct(Product product) {
    if (!products.contains(product)) {
      products.add(product);
    }
    setState(() {});
  }

  //add product using map
  addProduct2(Map<String, dynamic> product) {
    print(product);
    if (!products2.contains(product)) {
      products2.add(product);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu),
        title: Text(
          "Product List",
          //using of google fonts
          style: GoogleFonts.aBeeZee(
            color: Colors.yellow,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BottomSheetExample(),
                ),
              );
            },
            icon: Icon(Icons.add),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.more_vert),
          ),
        ],
      ),
      // body: products.isNotEmpty
      //     ? ListView.builder(
      //         itemCount: products.length,
      //         itemBuilder: (context, index) {
      //           return ListTile(
      //             onTap: () {
      //               Navigator.push(
      //                   context,
      //                   MaterialPageRoute(
      //                       builder: (context) => ProductDetailScreen(
      //                             product: products[index],
      //                           )));
      //             },
      //             leading: CircleAvatar(
      //               backgroundImage: NetworkImage("${products[index].image}"),
      //             ),
      //             title: Text("${products[index].name}"),
      //             subtitle: Text("${products[index].price}"),
      //             trailing: Text("${products[index].rating}"),
      //           );
      //         },
      //       )
      //     : Center(
      //         child: Text("No Products Available!"),
      //       ),

      body: products2.isNotEmpty
          ? ListView.builder(
              itemCount: products2.length,
              itemBuilder: (context, index) {
                return ListTile(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ProductDetailScreen(
                                  product: products[index],
                                )));
                  },
                  leading: CircleAvatar(
                    backgroundImage:
                        NetworkImage("${products2[index]["image"]}"),
                  ),
                  title: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("${products2[index]["name"]}"),
                      Text("${products2[index]["description"]}"),
                    ],
                  ),
                  // subtitle: Text("${products2[index]["description"]}"),
                  trailing: Text("${products2[index]["rating"]}"),
                );
              },
            )
          : Center(
              child: Text("No Product"),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddProductScreen(
                        submitCallback: addProduct,
                        submitUsingMapCallback: addProduct2,
                      )));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

///stf
///stl

import 'package:flutter/material.dart';

class BottomSheetExample extends StatefulWidget {
  const BottomSheetExample({Key? key}) : super(key: key);

  @override
  _BottomSheetExampleState createState() => _BottomSheetExampleState();
}

class _BottomSheetExampleState extends State<BottomSheetExample> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bottom Sheet Example"),
      ),
      body: Center(
        child: TextButton(
          onPressed: () {
            showModalBottomSheet(
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(20))),
                //  enableDrag: false,
                //isDismissible: false,
                context: context,
                builder: (BuildContext context) => buildBottomSheet());
          },
          child: Text("Open Bottom Sheet"),
        ),
      ),
    );
  }

  buildBottomSheet() {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      maxChildSize: 0.7,
      minChildSize: 0.5,
      builder: (_, ScrollController scrollController) {
        return Container(
          color: Colors.green,
          child: ListView(
            controller: scrollController,
            children: [
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
              Container(
                child: Text("TExt Text"),
              ),
            ],
          ),
        );
      },
    );
  }
}

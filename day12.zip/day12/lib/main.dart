import 'package:flutter/material.dart';

import 'simple_curd_app.dart';

void main() {
  //runApp(MyApp());
  //runApp(CalculatorApp());
  //runApp(SimpleCurdApp());
  // runApp(EMICalculatorApp());
  runApp(SimpleCurdApp());
}

//push()
//pop()

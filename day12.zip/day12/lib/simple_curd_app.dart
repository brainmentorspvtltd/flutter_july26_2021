import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'screens/home_screen.dart';

class SimpleCurdApp extends StatelessWidget {
  const SimpleCurdApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Simple Curd",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple,
        appBarTheme: AppBarTheme(
          textTheme: GoogleFonts.abrilFatfaceTextTheme(),
        ),
        textTheme: GoogleFonts.abrilFatfaceTextTheme(),
      ),
      home: HomeScreen(),
    );
  }
}

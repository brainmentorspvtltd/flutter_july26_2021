import 'package:flutter/material.dart';

class MyInputField extends StatelessWidget {
  const MyInputField({
    Key? key,
    required this.hintText,
    required this.onSave,
    required this.labelText,
  }) : super(key: key);
  final String hintText;
  final String labelText;
  final Function onSave;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      validator: (value) {
        if (value!.isEmpty) return "Please Enter Value";
      },
      onSaved: (value) {
        onSave(value);
      },
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        // enabledBorder: InputBorder.none,
        filled: true,
        fillColor: Colors.blueGrey[100],
        contentPadding: EdgeInsets.all(10),
        isDense: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(50),
        ),
      ),
    );
  }
}

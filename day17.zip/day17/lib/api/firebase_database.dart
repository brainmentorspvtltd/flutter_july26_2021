import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;

class Database {
  create() {}
  update() {}
  static read() async {
    final collectionReference = _firestore.collection("products");
    final QuerySnapshot querySnapshot = await collectionReference.get();
    print(querySnapshot.docs.first.id);
  }

  delete() {}
}

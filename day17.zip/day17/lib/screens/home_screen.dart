import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_demo/api/firebase_database.dart';
import 'package:google_sign_in/google_sign_in.dart';

final googleSingIn = GoogleSignIn();

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key, required this.auth}) : super(key: key);

  final FirebaseAuth auth;
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  _signOut() async {
    await widget.auth.signOut();
    await googleSingIn.signOut();
  }

  @override
  void initState() {
    Database.read();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final photoUrl = widget.auth.currentUser!.photoURL;

    return Scaffold(
      appBar: AppBar(
        title: Text("Home Screen"),
        actions: [
          TextButton(
            onPressed: () {
              _signOut();
            },
            child: Text(
              "Logout",
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
          PopupMenuButton(
            icon: CircleAvatar(
              radius: 15,
              child: photoUrl == null
                  ? Text(
                      "${widget.auth.currentUser!.displayName!.substring(0, 1).toUpperCase()}",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    )
                  : Image.network(photoUrl),
            ),
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem(value: "logout", child: Text("Logout")),
              ];
            },
          ),
        ],
      ),
      body: Center(
        child: Text("Home Screen"),
      ),
    );
  }
}

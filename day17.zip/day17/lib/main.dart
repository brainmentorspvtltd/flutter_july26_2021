import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'screens/landing_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // await FirebaseAuth.instance.useAuthEmulator('localhost', 9099);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Flutter App Demo",
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.light,
      home: LandingScreen(),
    );
  }
}

// void registerAccount(String email, String displayName, String password,
//     void Function(FirebaseAuthException e) errorCallback) async {
//   try {
//     var credential = await FirebaseAuth.instance
//         .createUserWithEmailAndPassword(email: email, password: password);
//     await credential.user!.updateProfile(displayName: displayName);
//   } on FirebaseAuthException catch (e) {
//     errorCallback(e);
//   }
// }

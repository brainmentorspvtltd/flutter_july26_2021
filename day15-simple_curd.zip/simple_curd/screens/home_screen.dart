import 'package:flutter/material.dart';
import 'package:flutter_learning/simple_curd/screens/add_product_screen.dart';
import 'package:flutter_learning/simple_curd/screens/bottom_sheet_demo.dart';
import 'package:flutter_learning/simple_curd/screens/edit_product_screen.dart';
import 'package:flutter_learning/simple_curd/screens/product_detail_screen.dart';
import 'package:flutter_learning/simple_curd/widgets/product_card.dart';
import 'package:flutter_learning/simple_curd/widgets/product_card2.dart';

import '../models/product_model.dart';
import 'bottom_sheet_example.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String _appTitle = "Product List";
  List<Widget> _widgetOptions = <Widget>[
    ProductListWidget(),
    AddProductScreen(submitCallback: () {}),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "$_appTitle",
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BottomSheetExample(),
                ),
              );
            },
            icon: Icon(Icons.add),
          ),
        ],
      ),
      body: Center(child: _widgetOptions[_selectedIndex]),
      drawer: _myDrawer(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.pink[900],
        unselectedItemColor: Colors.white,
        selectedItemColor: Colors.yellow,
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _appTitle = index == 0 ? "Product List" : "Add New Product";
            _selectedIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            backgroundColor: Colors.purpleAccent,
            label: "Home",
            icon: Icon(Icons.home),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.green,
            label: "Add Product",
            icon: Icon(Icons.account_circle),
          ),
        ],
      ),
    );
  }

  _myDrawer() {
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.pink[900],
            ),
            child: Text("Header"),
          ),
          ListTile(
            leading: Icon(Icons.how_to_reg),
            onTap: () {
              Navigator.of(context).pop();

              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BottomSheetDemo(),
                ),
              );
            },
            title: Text("Bottom Sheet Demo"),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.logout),
            onTap: () {},
            title: Text("logout"),
          )
        ],
      ),
    );
  }
}

class ProductListWidget extends StatefulWidget {
  const ProductListWidget({Key? key}) : super(key: key);

  @override
  _ProductListWidgetState createState() => _ProductListWidgetState();
}

class _ProductListWidgetState extends State<ProductListWidget> {
  List<Product> products = [];
  addProduct(Product product) {
    if (!products.contains(product)) {
      products.add(product);
    }
    setState(() {});
  }

  updateProduct(Product product) {
    print("EditedProduct is");
    print(product.name);

    products[products.indexWhere((p) => p.id == product.id)] = product;

    setState(() {});
  }

  removeProduct(Map<String, dynamic> product) {
    products.remove(product);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return products.isNotEmpty
        ? Padding(
            padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.of(context).size.width * 0.03),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                Text(
                  "Horizontal List View",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  height: 200,
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: products.length,
                    itemBuilder: (context, index) {
                      return ProductCard2(product: products[index]);
                    },
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "Vertical List View",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: products.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>
                                  ProductDetailScreen(product: products[index]),
                            ),
                          );
                        },
                        child: Dismissible(
                          key: Key(index.toString()),
                          direction: DismissDirection.startToEnd,
                          secondaryBackground: Container(
                            color: Colors.green,
                          ),
                          background: Container(
                            color: Colors.red,
                          ),
                          confirmDismiss: (direction) async {
                            if (direction == DismissDirection.startToEnd) {
                              products.removeAt(index);
                              setState(() {});
                            }
                          },
                          child: ProductCard(
                            product: products[index],
                            editProduct: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => EditProductScreen(
                                    product: products[index],
                                    updateProduct: updateProduct,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          )
        : Center(
            child: Text("No Products Available!"),
          );
  }
}

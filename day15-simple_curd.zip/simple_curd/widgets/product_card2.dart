import 'package:flutter/material.dart';
import 'package:flutter_learning/simple_curd/models/product_model.dart';

class ProductCard2 extends StatelessWidget {
  const ProductCard2({Key? key, required this.product}) : super(key: key);
  final Product product;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 2,
          ),
        ],
      ),
      width: 100,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 140,
            color: Colors.black26,
            child: Image(
              image: NetworkImage(
                product.image,
              ),
              fit: BoxFit.cover,
            ),
          ),
          Spacer(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "${product.name}",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Text("${product.rating}"),
                    Icon(
                      Icons.star,
                      size: 14,
                      color: Colors.orange,
                    ),
                    SizedBox(width: 3),
                    Text("${product.price}"),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

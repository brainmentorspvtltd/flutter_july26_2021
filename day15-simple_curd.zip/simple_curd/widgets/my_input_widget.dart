import 'package:flutter/material.dart';

class MyInputField extends StatelessWidget {
  const MyInputField({
    Key? key,
    required this.hintText,
    required this.onSave,
    required this.labelText,
    this.initialValue,
  }) : super(key: key);
  final String hintText;
  final String labelText;
  final Function onSave;
  final dynamic initialValue;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      initialValue: initialValue,
      validator: (value) {
        if (value!.isEmpty) return "Please Enter Value";
      },
      onSaved: (value) {
        onSave(value);
      },
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        // enabledBorder: InputBorder.none,
        focusColor: Colors.orange,
        filled: true,
        fillColor: Colors.grey[200],
        contentPadding: EdgeInsets.all(10),
        isDense: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(50),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

class SimpleCurdApp extends StatelessWidget {
  const SimpleCurdApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Simple Curd",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple,
        // appBarTheme: AppBarTheme(
        //   textTheme: GoogleFonts.robotoTextTheme(),
        // ),
        // textTheme: GoogleFonts.robotoTextTheme(),
      ),
      home: HomeScreen(),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class ProductDetailScreen extends StatelessWidget {
  //final Product product;
  final Map<String, dynamic> product;
  final Function removeProduct;
  const ProductDetailScreen({
    Key? key,
    required this.product,
    required this.removeProduct,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product Detail"),
      ),
      body: Container(
        width: double.infinity,
        alignment: Alignment.center,
        child: Column(
          children: [
            Image.network(
              product["image"],
              height: 200,
              width: 200,
            ),
            Text(
              "${product["name"]}",
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text("Product Type: ${product["productType"]}"),
            SizedBox(height: 10),
            Container(
              height: 80,
              width: double.infinity,
              color: Colors.pink[50],
              alignment: Alignment.center,
              child: Text("${product["description"]}"),
            ),

            //by using package
            RatingBar.builder(
              initialRating: double.parse(product["rating"]),
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.green,
                size: 10,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),

            //own start stateless widget
            StarRating(
              color: Colors.pink,
              rating: 3.5,
              startCourt: 5,
            ),

            Container(
              width: double.infinity,
              child: Wrap(
                alignment: WrapAlignment.spaceBetween,
                direction: Axis.horizontal,
                spacing: 10,
                children: [
                  Chip(
                    label: Text("${product["rating"]}"),
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Chip(
                      label:
                          Text("Is Fav : ${product["isFav"] ? "Yes" : "No"}")),
                  Chip(
                      label: Text(
                          "Is Available: ${product["isAvailable"] ? "Yes" : "No"}")),
                ],
              ),
            ),
            SizedBox(height: 30),
            OutlinedButton(
              onPressed: () {
                removeProduct(product);
                Navigator.of(context).pop();
              },
              child: Text("Delete"),
            )
          ],
        ),
      ),
    );
  }
}

class StarRating extends StatelessWidget {
  const StarRating({
    Key? key,
    this.startCourt = 5,
    this.rating = .0,
    required this.color,
  }) : super(key: key);

  final int startCourt;
  final double rating;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children:
          List.generate(startCourt, (index) => _buildStart(context, index)),
    );
  }

  _buildStart(BuildContext context, index) {
    Icon? icon;
    if (index >= rating) {
      icon = Icon(
        Icons.star_border,
        color: color,
      );
    } else if (index > rating - 1 && index < rating) {
      icon = Icon(
        Icons.star_half,
        color: color,
      );
    } else {
      icon = Icon(
        Icons.star,
        color: color,
      );
    }

    return InkResponse(
      onTap: () {},
      child: icon,
    );
  }
}

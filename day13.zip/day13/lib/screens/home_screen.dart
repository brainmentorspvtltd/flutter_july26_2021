import 'package:flutter/material.dart';
import 'package:flutter_learning/screens/add_product_screen.dart';
import 'package:flutter_learning/screens/product_detail_screen.dart';

import '../models/product_model.dart';
import 'bottom_sheet_example.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> products = [];
  List<Map<String, dynamic>> products2 = [];

  //add product method
  addProduct(Product product) {
    if (!products.contains(product)) {
      products.add(product);
    }
    setState(() {});
  }

  //add product using map
  addProduct2(Map<String, dynamic> product) {
    print("Product is $product");
    if (!products2.contains(product)) {
      products2.add(product);
    }
    setState(() {});
  }

  removeProduct(Map<String, dynamic> product) {
    products2.remove(product);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Product List",
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BottomSheetExample(),
                ),
              );
            },
            icon: Icon(Icons.add),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.more_vert),
          ),
        ],
      ),
      // body: products.isNotEmpty
      //     ? ListView.builder(
      //         itemCount: products.length,
      //         itemBuilder: (context, index) {
      //           return ListTile(
      //             onTap: () {
      //               Navigator.push(
      //                   context,
      //                   MaterialPageRoute(
      //                       builder: (context) => ProductDetailScreen(
      //                             product: products[index],
      //                           )));
      //             },
      //             leading: CircleAvatar(
      //               backgroundImage: NetworkImage("${products[index].image}"),
      //             ),
      //             title: Text("${products[index].name}"),
      //             subtitle: Text("${products[index].price}"),
      //             trailing: Text("${products[index].rating}"),
      //           );
      //         },
      //       )
      //     : Center(
      //         child: Text("No Products Available!"),
      //       ),

      body: products2.isNotEmpty
          ? ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: products2.length,
              itemBuilder: (context, index) {
                return ListTile(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ProductDetailScreen(
                                  product: products2[index],
                                  removeProduct: removeProduct,
                                )));
                  },
                  leading: CircleAvatar(
                    backgroundImage:
                        NetworkImage("${products2[index]["image"]}"),
                  ),
                  title: Text("${products2[index]["name"]}"),
                  subtitle: Text("${products2[index]["description"]}"),
                  trailing: Text("${products2[index]["rating"]}"),
                );
              },
            )
          : Center(
              child: Text("No Product"),
            ),
      // body: Padding(
      //   padding: const EdgeInsets.all(8.0),
      //   child: GridView.builder(
      //     itemCount: 50,
      //     gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      //       crossAxisCount: 3,
      //       // childAspectRatio: 2 / 1,
      //       crossAxisSpacing: 8,
      //       mainAxisSpacing: 10,
      //     ),
      //     itemBuilder: (BuildContext context, index) {
      //       return GestureDetector(
      //         onTap: () {},
      //         child: Card(
      //           child: Container(
      //             child: Text("Index value is $index"),
      //           ),
      //         ),
      //       );
      //     },
      //   ),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddProductScreen(
                        submitCallback: addProduct,
                        submitUsingMapCallback: addProduct2,
                      )));
        },
        child: Icon(Icons.add),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.pink[900],
              ),
              child: Text("Header"),
            ),
            ListTile(
              leading: Icon(Icons.poll_rounded),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => AddProductScreen(
                      submitCallback: addProduct,
                      submitUsingMapCallback: addProduct2,
                    ),
                  ),
                );
              },
              title: Text("Add Product"),
            ),
            ListTile(
              leading: Icon(Icons.how_to_reg),
              onTap: () {},
              title: Text("Register"),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.logout),
              onTap: () {},
              title: Text("logout"),
            )
          ],
        ),
      ),
    );
  }
}

///stf
///stl

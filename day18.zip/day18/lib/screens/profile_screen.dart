import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    Key? key,
    required this.auth,
  }) : super(key: key);
  final FirebaseAuth auth;

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  File? _image;

  void _pickImage(ImageSource source) async {
    final _imagePicker = ImagePicker();
    try {
      final image = await _imagePicker.pickImage(
        source: source,
      );
      final tempImage = File(image!.path);

      setState(() {
        _image = tempImage;
      });
    } on PlatformException catch (e) {
      print("Failed to pick image $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Center(
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            GestureDetector(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  builder: (context) => Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ListTile(
                        leading: Icon(Icons.camera),
                        title: Text("From Camera"),
                        onTap: () {
                          _pickImage(ImageSource.camera);
                        },
                      ),
                      ListTile(
                        onTap: () {
                          _pickImage(ImageSource.gallery);
                        },
                        leading: Icon(Icons.image),
                        title: Text("From Gallery"),
                      ),
                    ],
                  ),
                );
              },
              child: Container(
                height: 100,
                width: 100,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: _image != null ? Image.file(_image!) : Text("K"),
                ),
              ),
            ),
            SizedBox(height: 10),
            Text(
              "${widget.auth.currentUser!.displayName}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text("${widget.auth.currentUser!.email}"),
            SizedBox(height: 10),
            Text(
                "${widget.auth.currentUser!.emailVerified ? "Email is Verified" : "Email is Not Verified"}"),
          ],
        ),
      )),
    );
  }
}

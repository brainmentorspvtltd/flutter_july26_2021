import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_demo/api/firebase_database.dart';
import 'package:flutter_app_demo/screens/profile_screen.dart';
import 'package:google_sign_in/google_sign_in.dart';

final googleSingIn = GoogleSignIn();

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key, required this.auth}) : super(key: key);

  final FirebaseAuth auth;
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  _signOut() async {
    await widget.auth.signOut();
    await googleSingIn.signOut();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final photoUrl = widget.auth.currentUser!.photoURL;

    //WillPopScope is used to process whether to leave the current page or not.
    return WillPopScope(
      onWillPop: () async {
        return await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("Are you sure to Quit!!"),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  child: Text("Yes")),
              TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  child: Text("No")),
            ],
          ),
        );
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text("Home Screen"),
          actions: [
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(auth: widget.auth),
                  ),
                );
              },
              child: CircleAvatar(
                radius: 17,
                backgroundColor: Colors.white,
                child: CircleAvatar(
                  radius: 15,
                  child: photoUrl == null
                      ? Text(
                          "${widget.auth.currentUser!.displayName!.substring(0, 1).toUpperCase()}",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(50.0),
                          child: Image.network(photoUrl),
                        ),
                ),
              ),
            ),
            // TextButton(
            //   onPressed: () {
            //     _signOut();
            //   },
            //   child: Text(
            //     "Logout",
            //     style: TextStyle(
            //       color: Colors.white,
            //     ),
            //   ),
            // ),
            PopupMenuButton(
              onSelected: (String value) {
                if (value == "logout") {
                  _signOut();
                }
              },
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem(value: "AddItem", child: Text("AddItem")),
                  PopupMenuItem(value: "logout", child: Text("Logout")),
                ];
              },
            ),
          ],
        ),
        // body: FutureBuilder<QuerySnapshot>(
        //   future: Database.read(),
        //   builder: (BuildContext context, AsyncSnapshot snapshot) {
        //     if (snapshot.hasError) {
        //       return Center(child: Text("Something went wrong"));
        //     }
        //
        //     if (snapshot.connectionState == ConnectionState.done) {
        //       final QuerySnapshot querySnapshot = snapshot.data;
        //       final List<DocumentSnapshot> documents = querySnapshot.docs;
        //
        //       return ListView(
        //           children: documents
        //               .map((doc) => Card(
        //                     child: ListTile(
        //                       title: Text(doc['name']),
        //                       subtitle: Text("${doc['description']}"),
        //                       trailing: Text("${doc['price']}"),
        //                     ),
        //                   ))
        //               .toList());
        //     }
        //     return Center(
        //       child: CircularProgressIndicator(),
        //     );
        //   },
        // ),

        body: Column(
          children: [
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ElevatedButton(
                  onPressed: () {
                    final Map<String, dynamic> map = {
                      "name": "Sony TV",
                      "description": "This is desc",
                      "price": 388,
                    };

                    Database.create(map);
                  },
                  child: Text("Add Item"),
                ),
              ],
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: Database.read2(),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasError) {
                    return Center(
                      child: Text("Something went wrong!"),
                    );
                  }

                  if (snapshot.hasData) {
                    final QuerySnapshot querySnapshot = snapshot.data;
                    final List<DocumentSnapshot> documents = querySnapshot.docs;
                    return ListView(
                        children: documents
                            .map((doc) => Card(
                                  child: ListTile(
                                    title: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("${doc['name']}"),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              child: TextButton(
                                                  onPressed: () {
                                                    Database.delete(doc.id);
                                                  },
                                                  child: Text("Delete")),
                                            ),
                                            Expanded(
                                              child: TextButton(
                                                  onPressed: () {
                                                    final Map<String, dynamic>
                                                        data = {
                                                      "name": "Panasonic TV",
                                                      "description":
                                                          "This is good TV",
                                                      "price": 555,
                                                    };

                                                    Database.update(
                                                        doc.id, data);
                                                  },
                                                  child: Text("Update")),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    subtitle: Text("${doc['description']}"),
                                    leading: Text("${doc['price']}"),
                                  ),
                                ))
                            .toList());
                  }

                  return Center(child: CircularProgressIndicator());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

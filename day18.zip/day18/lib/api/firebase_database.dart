import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
final collectionReference = _firestore.collection("products");

class Database {
  static create(Map<String, dynamic> data) {
    collectionReference.add(data);
  }

  static update(String docId, Map<String, dynamic> data) {
    collectionReference.doc(docId).update(data);
  }

  //return future (so we can use FutureBuilder() widget to display content)
  static Future<QuerySnapshot> read() async {
    final QuerySnapshot querySnapshot = await collectionReference.get();
    return querySnapshot;
  }

  //return stream of data so we can use StreamBuilder() widget to display data
  static Stream<QuerySnapshot> read2() {
    final stream = collectionReference.snapshots();
    return stream;
  }

  static delete(String docId) {
    collectionReference.doc(docId).delete();
  }
}

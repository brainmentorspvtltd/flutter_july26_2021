import 'package:api_calls/models/post.dart';
import 'package:flutter/material.dart';

class PostDetailScreen extends StatefulWidget {
  const PostDetailScreen({Key? key}) : super(key: key);

  @override
  _PostDetailScreenState createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  @override
  Widget build(BuildContext context) {
    //if you are using routes table in MaterialApp() then this is the method to fetch arguments
    final post = ModalRoute.of(context)!.settings.arguments as Post;

    return Scaffold(
      body: Center(
        child: Text("Product Detail Screen"),
      ),
    );
  }
}

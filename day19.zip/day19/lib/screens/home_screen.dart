import 'package:api_calls/api/api_calls.dart';
import 'package:api_calls/models/photo.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Screen"),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed("/add-post");
            },
            icon: Icon(Icons.add),
          ),
        ],
      ),
      body: FutureBuilder(
        future: APICalls().getPhotos(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            final List<Photo> photos = snapshot.data;
            return ListView(
              children: photos
                  .map(
                    (photo) => ListTile(
                      onTap: () {
                        Navigator.of(context)
                            .pushNamed("/post-detail", arguments: photo);
                      },
                      leading: CircleAvatar(
                        child: Image.network(photo.thumbnailUrl),
                      ),
                      title: Text(photo.title),
                    ),
                  )
                  .toList(),
            );
          }
          return Center(child: Text("Please Wait..."));
        },
      ),
      // body: FutureBuilder(
      //   future: APICalls().getPosts(),
      //   builder: (BuildContext context, AsyncSnapshot snapshot) {
      //     if (snapshot.hasData) {
      //       final List<Post> posts = snapshot.data;
      //       return ListView.builder(
      //         itemCount: posts.length,
      //         itemBuilder: (BuildContext context, index) {
      //           return ListTile(
      //             leading: CircleAvatar(),
      //             title: Text("${posts[index].title}"),
      //             subtitle: Text("${posts[index].body}"),
      //           );
      //         },
      //       );
      //     }
      //     return Center(child: Text("Please Wait..."));
      //   },
      // ),
    );
  }
}

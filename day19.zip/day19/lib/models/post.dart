class Post {
  final int id;
  final int userId;
  final String title;
  final String body;

  Post({
    required this.id,
    required this.userId,
    required this.title,
    required this.body,
  });

  factory Post.fromJson(Map<String, dynamic> data) {
    return Post(
      userId: data["userId"],
      id: data["id"],
      title: data["title"],
      body: data["body"],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "id": id,
      "userId": userId,
      "title": title,
      "body": body,
    };
  }
}

//for backend api calls we need some package like http or dio
//there are lot of method for "http"
// get(), post)(), delete(), put(), etc
//From Backend API we will received "json string"
//then we need to covert this json string into "Map<String, dynamic>"

//then we can put this map into our own data class

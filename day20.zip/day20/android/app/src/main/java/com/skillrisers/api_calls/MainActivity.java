package com.skillrisers.api_calls;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

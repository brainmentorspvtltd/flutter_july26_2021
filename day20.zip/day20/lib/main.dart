import 'package:api_calls/screens/home_screen.dart';
import 'package:api_calls/screens/page_view_screen.dart';
import 'package:api_calls/screens/web_view_demo_screen.dart';
import 'package:flutter/material.dart';

import 'screens/add_post_screen.dart';
import 'screens/post_detail_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home: HomeScreen(),
      initialRoute: "/",
      routes: {
        "/": (context) => HomeScreen(),
        "add-post": (context) => AddPostScreen(),
        "post-detail": (context) => PostDetailScreen(),
        "page-view-demo": (context) => PageViewScreen(),
        "web-view-demo": (context) => WebViewDemoScreen(),
      },

      // onGenerateRoute: (settings) {
      //   if (settings.name == "/") {}
      // },
    );
  }
}

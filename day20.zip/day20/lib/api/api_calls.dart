import 'dart:convert';

import 'package:api_calls/models/photo.dart';
import 'package:api_calls/models/post.dart';
import 'package:http/http.dart' as http;

class APICalls {
  final String baseUrl = "https://jsonplaceholder.typicode.com";

  Future<List<Photo>> getPhotos() async {
    try {
      final http.Response response =
          await http.get(Uri.parse(baseUrl + "/photos"));
      //we received json string
      //return response.body;

      //after decode we received List<dynamic>
      //return jsonDecode(response.body);

      //cast List<dynamic> to Map<String, dynamic> don't work because multiple items received
      //return jsonDecode(response.body) as Map<String, dynamic>;

      //return this data
      //return jsonDecode(response.body).cast<Map<String, dynamic>>();

      final parsedData = jsonDecode(response.body).cast<Map<String, dynamic>>();
      final List<Photo> photos =
          parsedData.map<Photo>((json) => Photo.fromJson(json)).toList();
      return photos;
    } catch (e) {
      throw "Oops ${e.toString()}";
    }
  }

  Future<List<Post>> getPosts() async {
    String url = "$baseUrl/posts";
    final response = await http.get(Uri.parse(url));
    //we received json string in response body from api
    return parsePosts(response.body);
  }

  List<Post> parsePosts(String responseBody) {
    final parsedData = jsonDecode(responseBody).cast<Map<String, dynamic>>();
    final List<Post> posts =
        parsedData.map<Post>((json) => Post.fromJson(json)).toList();
    return posts;
  }

  Future<Post> addPost(Map<String, dynamic> data) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl + "/posts"),
        body: jsonEncode(data),
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
      );
      final parsedData = jsonDecode(response.body) as Map<String, dynamic>;
      return Post.fromJson(parsedData);
    } catch (e) {
      throw "Opps have Error $e";
    }
  }
}

//Dart is a single threaded language (main Isolate)

//Isolate

//http Hyper Text Transport Protocols

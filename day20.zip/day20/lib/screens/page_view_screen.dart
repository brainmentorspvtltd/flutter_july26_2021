import 'package:flutter/material.dart';

class PageViewScreen extends StatefulWidget {
  @override
  _PageViewScreenState createState() => _PageViewScreenState();
}

class _PageViewScreenState extends State<PageViewScreen> {
  @override
  Widget build(BuildContext context) {
    final PageController _pageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );
    int indexValue = 0;

    return Scaffold(
      appBar: AppBar(
        title: Text("Page View Demo"),
      ),
      // body: PageView(
      //   onPageChanged: (value){
      //     setState(() {
      //       indexValue =value;
      //     });
      //   },
      //   controller: _pageController,
      //   scrollDirection: Axis.vertical,
      //   children: [
      //     Container(color: Colors.green),
      //     Container(color: Colors.yellow),
      //     Container(color: Colors.red),
      //     Container(color: Colors.orange),
      //
      //
      //   ],
      // ),

      body: PageView.builder(
        controller: _pageController,
        pageSnapping: true,
        physics: BouncingScrollPhysics(),
        itemBuilder: (context, index) {
          return Container(
            color: index % 2 == 0 ? Colors.deepOrangeAccent : Colors.grey,
          );
        },
      ),
    );
  }
}

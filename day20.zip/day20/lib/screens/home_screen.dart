import 'package:api_calls/api/api_calls.dart';
import 'package:api_calls/models/post.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<Post> posts;

  @override
  void initState() {
    loadPosts();
    super.initState();
  }

  Future<void> loadPosts() async {
    setState(() {
      posts = [];
    });
    final data = await APICalls().getPosts();
    setState(() {
      posts = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Screen"),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed("web-view-demo");
            },
            icon: Icon(Icons.http),
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed("add-post");
            },
            icon: Icon(Icons.add),
          ),
          //page-view-demo
          IconButton(
            onPressed: () {
              Navigator.of(context).pushNamed("page-view-demo");
            },
            icon: Icon(Icons.router),
          ),
        ],
      ),

      body: posts.isNotEmpty
          ? RefreshIndicator(
              onRefresh: loadPosts,
              child: ListView.builder(
                itemCount: posts.length,
                itemBuilder: (BuildContext context, index) {
                  return ListTile(
                    onTap: () {
                      Navigator.of(context)
                          .pushNamed("post-detail", arguments: posts[index]);
                    },
                    leading: CircleAvatar(),
                    title: Text("${posts[index].title}"),
                    subtitle: Text("${posts[index].body}"),
                  );
                },
              ),
            )
          : Center(
              child: CircularProgressIndicator(),
            ),

      // body: FutureBuilder(
      //   future: APICalls().getPosts(),
      //   builder: (BuildContext context, AsyncSnapshot snapshot) {
      //     if (snapshot.hasData) {
      //       final List<Photo> photos = snapshot.data;
      //       return ListView(
      //         children: photos
      //             .map(
      //               (photo) => ListTile(
      //                 onTap: () {
      //                   Navigator.of(context)
      //                       .pushNamed("/post-detail", arguments: photo);
      //                 },
      //                 leading: CircleAvatar(
      //                   child: Image.network(photo.thumbnailUrl),
      //                 ),
      //                 title: Text(photo.title),
      //               ),
      //             )
      //             .toList(),
      //       );
      //     }
      //     return Center(child: Text("Please Wait..."));
      //   },
      // ),
      // body: RefreshIndicator(
      //   onRefresh: () async {
      //     await APICalls().getPosts();
      //   },
      //   child: FutureBuilder<List<Post>>(
      //     future: APICalls().getPosts(),
      //     builder: (BuildContext context, AsyncSnapshot snapshot) {
      //       if (snapshot.hasError) {
      //         return Center(
      //           child: Text("Opps Something Went Wrong!"),
      //         );
      //       }
      //
      //       if (snapshot.hasData) {
      //         final posts = snapshot.data;
      //         return ListView.builder(
      //           itemCount: posts.length,
      //           itemBuilder: (BuildContext context, index) {
      //             return ListTile(
      //               onTap: () {
      //                 Navigator.of(context)
      //                     .pushNamed("post-detail", arguments: posts[index]);
      //               },
      //               leading: CircleAvatar(),
      //               title: Text("${posts[index].title}"),
      //               subtitle: Text("${posts[index].body}"),
      //             );
      //           },
      //         );
      //       }
      //       return Center(child: Text("Please Wait..."));
      //     },
      //   ),
      // ),
    );
  }
}

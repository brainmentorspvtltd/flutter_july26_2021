import 'package:api_calls/api/api_calls.dart';
import 'package:flutter/material.dart';

class AddPostScreen extends StatefulWidget {
  const AddPostScreen({Key? key}) : super(key: key);

  @override
  _AddPostScreenState createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Post'),
      ),
      body: Center(
        child: OutlinedButton(
          onPressed: () {
            final data = {
              "title": 'Adding From My App',
              "body": 'This is the body of the post',
              "userId": 90,
            };

            APICalls().addPost(data);
          },
          child: Text("Add Item"),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_learning/models/product_model.dart';
import 'package:flutter_learning/widgets/my_input_widget.dart';

class EditProductScreen extends StatefulWidget {
  EditProductScreen({
    Key? key,
    required this.product,
    required this.updateProduct,
  }) : super(key: key);
  final Product product;
  final Function updateProduct;
  @override
  _EditProductScreenState createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  String? productId;
  String? name;
  String? description;
  String? price;
  String? image;
  String? rating;
  bool isFav = false;
  bool isAvailable = false;
  String productType = "Laptop";

  void _submit() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final product = Product(
        id: productId!,
        name: name!,
        description: description!,
        price: double.parse(price!),
        image: image!,
        rating: double.parse(rating!),
        isAvailable: isAvailable,
        isFav: isFav,
        productType: productType,
      );
      widget.updateProduct(product);
    }
    Navigator.of(context).pop();
  }

  @override
  void initState() {
    productId = widget.product.id;
    isAvailable = widget.product.isAvailable;
    isFav = widget.product.isFav;
    productType = widget.product.productType;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text("Edit Product"),
        ),
        body: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: ListView(
              children: [
                TextFormField(
                    initialValue: productId,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: "ProductId",
                      focusColor: Colors.orange,
                      filled: true,
                      fillColor: Colors.blueGrey[100],
                      contentPadding: EdgeInsets.all(10),
                      isDense: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(50),
                      ),
                    )),
                SizedBox(height: 20),
                MyInputField(
                  initialValue: widget.product.name,
                  labelText: "Name",
                  hintText: "Enter Your Name",
                  onSave: (value) {
                    name = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  initialValue: widget.product.description,
                  labelText: "Description",
                  hintText: "Enter Description",
                  onSave: (value) {
                    description = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  initialValue: widget.product.price.toString(),
                  labelText: "Price",
                  hintText: "Enter Price",
                  onSave: (value) {
                    price = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  initialValue: widget.product.image,
                  labelText: "Image",
                  hintText: "Enter Product Image",
                  onSave: (value) {
                    image = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  initialValue: widget.product.rating.toString(),
                  labelText: "Rating",
                  hintText: "Enter Rating",
                  onSave: (value) {
                    rating = value;
                  },
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Checkbox(
                      value: isFav,
                      onChanged: (value) {
                        setState(() {
                          isFav = value!;
                        });
                      },
                    ),
                    Text("Is Fav"),
                  ],
                ),
                Divider(
                  height: 30,
                  color: Colors.purple[100],
                  thickness: 2,
                ),
                Container(
                  width: double.infinity,
                  height: 100,
                  color: Colors.pink[100],
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Radio<String>(
                              value: "Laptop",
                              groupValue: productType,
                              onChanged: (value) {
                                setState(() {
                                  productType = value!;
                                });
                              }),
                          Text("Laptop"),
                        ],
                      ),
                      Row(
                        children: [
                          Radio<String>(
                              value: "Desktop",
                              groupValue: productType,
                              onChanged: (value) {
                                setState(() {
                                  productType = value!;
                                });
                              }),
                          Text("Desktop"),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Expanded(child: Text("Is Product Available")),
                    Text("Is Product Available"),
                    Spacer(),
                    Switch(
                      value: isAvailable,
                      onChanged: (value) {
                        setState(() {
                          isAvailable = value;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _submit,
                  child: Text("Update Product"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

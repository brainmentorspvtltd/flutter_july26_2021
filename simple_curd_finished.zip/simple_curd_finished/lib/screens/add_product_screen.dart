import 'package:flutter/material.dart';
import 'package:flutter_learning/models/product_model.dart';
import 'package:flutter_learning/widgets/my_input_widget.dart';
import 'package:uuid/uuid.dart';

class AddProductScreen extends StatefulWidget {
  AddProductScreen({
    Key? key,
    required this.submitCallback,
  }) : super(key: key);
  final Function submitCallback;

  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  String? name;
  String? description;
  String? price;
  String? image;
  String? rating;
  bool isFav = false;
  bool isAvailable = false;
  String productType = "Laptop";

  void _submit() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final uuid = Uuid();

      final product = Product(
        id: uuid.v4(),
        name: name!,
        description: description!,
        price: double.parse(price!),
        image: image!,
        rating: double.parse(rating!),
        isAvailable: isAvailable,
        isFav: isFav,
        productType: productType,
      );
      widget.submitCallback(product);
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text("Add New Product"),
        ),
        body: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: ListView(
              children: [
                MyInputField(
                  labelText: "Name",
                  hintText: "Enter Your Name",
                  onSave: (value) {
                    name = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  labelText: "Description",
                  hintText: "Enter Description",
                  onSave: (value) {
                    description = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  labelText: "Price",
                  hintText: "Enter Price",
                  onSave: (value) {
                    price = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  labelText: "Image",
                  hintText: "Enter Product Image",
                  onSave: (value) {
                    image = value;
                  },
                ),
                SizedBox(height: 20),
                MyInputField(
                  labelText: "Rating",
                  hintText: "Enter Rating",
                  onSave: (value) {
                    rating = value;
                  },
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Checkbox(
                      value: isFav,
                      onChanged: (value) {
                        setState(() {
                          isFav = value!;
                        });
                      },
                    ),
                    Text("Is Fav"),
                  ],
                ),
                Divider(
                  height: 30,
                  color: Colors.purple[100],
                  thickness: 2,
                ),
                Container(
                  width: double.infinity,
                  height: 100,
                  color: Colors.pink[100],
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Radio<String>(
                              value: "Laptop",
                              groupValue: productType,
                              onChanged: (value) {
                                setState(() {
                                  productType = value!;
                                });
                              }),
                          Text("Laptop"),
                        ],
                      ),
                      Row(
                        children: [
                          Radio<String>(
                              value: "Desktop",
                              groupValue: productType,
                              onChanged: (value) {
                                setState(() {
                                  productType = value!;
                                });
                              }),
                          Text("Desktop"),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Text("Is Product Available"),
                    Spacer(),
                    Switch(
                      value: isAvailable,
                      onChanged: (value) {
                        setState(() {
                          isAvailable = value;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _submit,
                  child: Text("Save Product"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

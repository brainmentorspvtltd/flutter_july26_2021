import 'package:flutter/material.dart';
import 'package:flutter_learning/screens/add_product_screen.dart';
import 'package:flutter_learning/screens/edit_product_screen.dart';
import 'package:flutter_learning/screens/product_detail_screen.dart';
import 'package:flutter_learning/widgets/product_card.dart';

import '../models/product_model.dart';
import 'bottom_sheet_example.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> products = [];

  //add product method
  addProduct(Product product) {
    if (!products.contains(product)) {
      products.add(product);
    }
    setState(() {});
  }

  updateProduct(Product product) {
    print("EditedProduct is");
    print(product.name);

    products[products.indexWhere((p) => p.id == product.id)] = product;

    setState(() {});
  }

  removeProduct(Map<String, dynamic> product) {
    products.remove(product);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Product List",
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BottomSheetExample(),
                ),
              );
            },
            icon: Icon(Icons.add),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.more_vert),
          ),
        ],
      ),
      body: products.isNotEmpty
          ? ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) =>
                            ProductDetailScreen(product: products[index]),
                      ),
                    );
                  },
                  child: Dismissible(
                    key: Key(index.toString()),
                    direction: DismissDirection.startToEnd,
                    secondaryBackground: Container(
                      color: Colors.green,
                    ),
                    background: Container(
                      color: Colors.red,
                    ),
                    confirmDismiss: (direction) async {
                      if (direction == DismissDirection.startToEnd) {
                        products.removeAt(index);
                        setState(() {});
                      }
                    },
                    child: ProductCard(
                      product: products[index],
                      editProduct: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => EditProductScreen(
                              product: products[index],
                              updateProduct: updateProduct,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                );

                // return ProductCard(
                //   productName: products[index].name,
                //   description: products[index].description,
                //   price: products[index].price,
                //   image: products[index].image,
                //   isFav: products[index].isFav,
                //   isAvailable: products[index].isAvailable,
                //   productType: products[index].productType,
                //   rating: products[index].rating,
                // );
                // return ListTile(
                //   onTap: () {
                //     Navigator.push(
                //       context,
                //       MaterialPageRoute(
                //         builder: (context) => EditProductScreen(
                //           product: products[index],
                //           updateProduct: updateProduct,
                //         ),
                //       ),
                //     );
                //   },
                //   leading: CircleAvatar(
                //     backgroundImage: NetworkImage("${products[index].image}"),
                //   ),
                //   title: Text("${products[index].name}"),
                //   subtitle: Text("${products[index].description}"),
                //   trailing: Text("${products[index].productType}"),
                // );
              },
            )
          : Center(
              child: Text("No Products Available!"),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  AddProductScreen(submitCallback: addProduct),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.pink[900],
              ),
              child: Text("Header"),
            ),
            ListTile(
              leading: Icon(Icons.poll_rounded),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) =>
                        AddProductScreen(submitCallback: addProduct),
                  ),
                );
              },
              title: Text("Add Product"),
            ),
            ListTile(
              leading: Icon(Icons.how_to_reg),
              onTap: () {},
              title: Text("Register"),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.logout),
              onTap: () {},
              title: Text("logout"),
            )
          ],
        ),
      ),
    );
  }
}

//model class
class Product {
  final String id;
  final String name;
  final String description;
  final double price;
  final String image;
  final double rating;
  final bool isFav;
  final bool isAvailable;
  final String productType;
  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.image,
    required this.rating,
    required this.isFav,
    required this.isAvailable,
    required this.productType,
  });
}

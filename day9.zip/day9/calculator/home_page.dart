import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //0xFF
      //#
      backgroundColor: Color(0xFF283637),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              //alignment: Alignment.centerRight,
              alignment: Alignment(1.0, 1.0),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "0",
                  style: TextStyle(
                    fontSize: 48,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "AC",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 2,
                ),
                CalculatorButton(
                  btnText: "%",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "÷",
                  fillValue: 0xFFFFC300,
                  textColor: Colors.black87,
                  flexValue: 1,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "7",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "8",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "9",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "x",
                  fillValue: 0xFFFFC300,
                  textColor: Colors.black87,
                  flexValue: 1,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "4",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "5",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "6",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "-",
                  fillValue: 0xFFFFC300,
                  textColor: Colors.black87,
                  flexValue: 1,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "1",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "2",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "3",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                ),
                CalculatorButton(
                  btnText: "+",
                  fillValue: 0xFFFFC300,
                  textColor: Colors.black87,
                  flexValue: 1,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "0",
                  fillValue: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 3,
                ),
                CalculatorButton(
                  btnText: "=",
                  fillValue: 0xFFFFC300,
                  textColor: Colors.black87,
                  flexValue: 1,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CalculatorButton extends StatelessWidget {
  final String btnText;
  final int fillValue;
  final Color textColor;
  final int flexValue;
  const CalculatorButton({
    Key? key,
    required this.btnText,
    required this.fillValue,
    required this.textColor,
    required this.flexValue,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flexValue,
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          color: Color(fillValue),
          border: Border.fromBorderSide(
            BorderSide(),
          ),
        ),
        child: TextButton(
          onPressed: () {},
          child: Text(
            "$btnText",
            style: TextStyle(
              fontSize: 30,
              color: textColor,
            ),
          ),
        ),
      ),
    );
  }
}

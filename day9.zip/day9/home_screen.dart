import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String name = "Ram";
  int age = 30;

  @override
  Widget build(BuildContext context) {
    print("Build Run");
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: Icon(Icons.menu),
        title: Text("Stateful Widget Demo"),
        actions: [
          Icon(Icons.more_vert),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Text(
                "$name",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.purple,
                elevation: 0,
              ),
              onPressed: () {
                setState(() => name = "Pawan");
                // setState(() {
                //   name = "Shayam";
                // });
              },
              child: Text("Change Name"),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            name = "Yogesh";
          });
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

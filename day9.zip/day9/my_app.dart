import 'package:flutter/material.dart';

import 'home_screen.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print("MyAppBuildMethod:");
    return MaterialApp(
      title: "Day 8",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

//TextButton()
//ElevatedButton()
//OutlineButton()
//InkWellButton()

import 'package:flutter/material.dart';

class SimpleApp extends StatelessWidget {
  const SimpleApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Simple Text Field App",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  String? password;
  bool isPasswordVisible = true;

  @override
  void initState() {
    emailController.addListener(() => setState(() {}));

    phoneController.addListener(() {
      final String text = phoneController.text.toLowerCase();
      phoneController.value = phoneController.value.copyWith(
        text: text,
        selection:
            TextSelection(baseOffset: text.length, extentOffset: text.length),
        composing: TextRange.empty,
      );
    });

    super.initState();
  }

  @override
  void dispose() {
    emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("TextField Example"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 40,
                child: _buildEmail(),
              ),
              SizedBox(height: 20),

              _buildPassword(),
              SizedBox(height: 20),
              _buildPhoneNumber(),
              SizedBox(height: 30),

              ElevatedButton(
                onPressed: () {
                  print("${emailController.text}");
                },
                child: Text("Submit"),
              ),
              // Container(
              //   height: 50,
              //   width: 300,
              //   color: Colors.deepPurpleAccent,
              //   child: Text(
              //       "Email is ${emailController.text} and Password ${password}"),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmail() => TextField(
        controller: emailController,
        keyboardType: TextInputType.emailAddress,
        textInputAction: TextInputAction.next,
        // autofocus: true,
        decoration: InputDecoration(
          labelText: "Email",
          hintText: "Enter your Email",
          prefixIcon: Icon(Icons.email),
          suffixIcon: emailController.text.isEmpty
              ? null
              : IconButton(
                  onPressed: () {
                    emailController.clear();
                  },
                  icon: Icon(Icons.close),
                ),

          isDense: true,
          //  icon: Icon(Icons.email),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          //enabledBorder: InputBorder.none,
          fillColor: Colors.grey,
          filled: true,
        ),
      );

  Widget _buildPassword() => TextField(
        obscureText: isPasswordVisible,
        onChanged: (value) {
          setState(() => password = value);
        },
        onSubmitted: (value) => setState(() => password = value),
        decoration: InputDecoration(
          labelText: "Password",
          hintText: "Enter password",
          errorText: "Please Add Correct Password",
          prefixIcon: Icon(Icons.security),

          suffixIcon: IconButton(
            onPressed: () {
              isPasswordVisible = !isPasswordVisible;
              setState(() {});
            },
            icon: isPasswordVisible
                ? Icon(Icons.visibility_off)
                : Icon(Icons.visibility),
          ),
          isDense: true,
          //  icon: Icon(Icons.email),
          border: OutlineInputBorder(),
        ),
      );

  Widget _buildPhoneNumber() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "PhoneNo",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          TextField(
            controller: phoneController,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              //decoration: TextDecoration.lineThrough,
              letterSpacing: 2,
            ),
            decoration: InputDecoration(
              hintText: "Enter Phone Number",
              hintStyle: TextStyle(color: Colors.yellow),
              fillColor: Colors.black,
              filled: true,
              border: OutlineInputBorder(),
              isDense: true,
            ),
          )
        ],
      );
}

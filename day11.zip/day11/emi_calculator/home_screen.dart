import 'dart:math';

import 'package:flutter/material.dart';

//stf (for stateful widgets)
//stl (for stateless widgets)

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _tenureType = "Month(s)";
  final _principalAmount = TextEditingController();
  final _interestRate = TextEditingController();
  final _tenure = TextEditingController();
  String _emiResult = "";

  final _formKey = GlobalKey<FormState>();

  void calculateEmi() {
    //Amortization
    // A = Payment amount per period
    // P = Initial Principal (Loan amount)
    // r = interest rate
    // n = total number of payments or periods
    double A = 0.0;
    int P = int.parse(_principalAmount.text);
    double r = double.parse(_interestRate.text) / 12 / 100;
    int n = _tenureType == "Year(s)"
        ? int.parse(_tenure.text) * 12
        : int.parse(_tenure.text);

    A = (P * r * pow((1 + r), n) / (pow((1 + r), n) - 1));
    _emiResult = A.toStringAsFixed(2);
  }

  showResultDialog() {
    return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Your(s) EMI"),
          content: Text(_emiResult),
          actions: [
            TextButton(onPressed: () {}, child: Text("Ok")),
            TextButton(onPressed: () {}, child: Text("Cancel")),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("EMI Calculator"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            children: [
              CircleAvatar(
                radius: 50,
                child: Icon(
                  Icons.account_balance,
                  size: 50,
                ),
              ),
              TextFormField(
                controller: _principalAmount,
                keyboardType: TextInputType.number,
                validator: (String? value) {
                  if (value!.isEmpty) return "Please enter value";
                },
                decoration: InputDecoration(
                    labelText: "Principal Amount",
                    hintText: "Enter Principal Amount",
                    prefixIcon: Icon(Icons.attach_money_outlined)),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _interestRate,
                keyboardType: TextInputType.number,
                validator: (String? value) {
                  if (value!.isEmpty) return "Please enter value";
                },
                decoration: InputDecoration(
                    labelText: "Rate of Interest",
                    hintText: "Enter value",
                    prefixIcon: Icon(Icons.attach_money_outlined)),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _tenure,
                      keyboardType: TextInputType.number,
                      validator: (String? value) {
                        if (value!.isEmpty) return "Please enter value";
                      },
                      decoration: InputDecoration(
                          labelText: "Term",
                          hintText: "Enter value",
                          prefixIcon: Icon(Icons.attach_money_outlined)),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: DropdownButton(
                      isExpanded: true,
                      value: _tenureType,
                      underline: SizedBox(),
                      onChanged: (String? value) {
                        setState(() {
                          _tenureType = value!;
                        });
                      },
                      items: <String>["Month(s)", "Year(s)"]
                          .map(
                            (value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    calculateEmi();
                    showResultDialog();
                  }
                },
                child: Text("Calculate"),
              )
            ],
          ),
        ),
      ),
    );
  }
}

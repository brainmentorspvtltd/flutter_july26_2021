import 'package:flutter/material.dart';
import 'package:flutter_learning/simple_curd/product_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Simple Curd App"),
      ),
      // body: ListView(
      //   children: items
      //       .map((item) => ListTile(
      //             leading: CircleAvatar(),
      //             title: Text(item),
      //             subtitle: Text("23423423"),
      //             trailing: Text("4.5"),
      //           ))
      //       .toList(),
      // ),

      // body: ListView.builder(
      //   itemCount: items.length,
      //   itemBuilder: (context, index) {
      //     return Text("${items[index]}");
      //   },
      // ),
      // body: ListView.separated(
      //   itemBuilder: (context, index) {
      //     return Text(items[index]);
      //   },
      //   separatorBuilder: (context, index) {
      //     return Divider();
      //   },
      //   itemCount: items.length,
      // ),
      // body: Center(
      //   child: OutlinedButton(
      //     onPressed: () {
      //       // Navigator.of(context).push(MaterialPageRoute(builder: (context){
      //       //   return AddProductScreen();
      //       // }));
      //
      //       // Navigator.of(context).push(
      //       //   MaterialPageRoute(
      //       //     builder: (context) => AddProductScreen(),
      //       //   ),
      //       // );
      //
      //       Navigator.push(context,
      //           MaterialPageRoute(builder: (context) => AddProductScreen()));
      //     },
      //     child: Text("Go To New Screen"),
      //   ),
      // ),

      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ListTile(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ProductDetailScreen(
                            product: products[index],
                          )));
            },
            leading: CircleAvatar(
              backgroundImage: NetworkImage("${products[index].image}"),
            ),
            title: Text("${products[index].name}"),
            subtitle: Text("${products[index].price}"),
            trailing: Text("${products[index].rating}"),
          );
        },
      ),
    );
  }
}

//model class
class Product {
  final String name;
  final String description;
  final double price;
  final String image;
  final double rating;
  Product({
    required this.name,
    required this.description,
    required this.price,
    required this.image,
    required this.rating,
  });
}

//list of products
List<Product> products = [
  Product(
    name: "Laptop Samsung",
    description: "This is about the laptop",
    price: 5500.00,
    image:
        "https://cdn.pixabay.com/photo/2014/05/02/21/49/laptop-336373__340.jpg",
    rating: 4.5,
  ),
  Product(
    name: "Apple Tab",
    description: "This is about the laptop",
    price: 33.00,
    image:
        "https://cdn.pixabay.com/photo/2014/05/02/21/49/laptop-336373__340.jpg",
    rating: 4.5,
  ),
  Product(
    name: "LG Monitor",
    description: "This is about the laptop",
    price: 2555.00,
    image:
        "https://cdn.pixabay.com/photo/2014/05/02/21/49/laptop-336373__340.jpg",
    rating: 4.5,
  ),
];

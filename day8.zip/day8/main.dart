import 'package:flutter/material.dart';

import 'my_app.dart';

// void main() {
//   runApp(
//     MaterialApp(
//         title: "Day 8",
//         theme: ThemeData(
//           primarySwatch: Colors.orange,
//         ),
//         home: Scaffold(
//           // appBar: AppBar(
//           //   title: Text("Day 8"),
//           // ),
//           body: SafeArea(
//             child: Stack(
//               //  alignment: Alignment.center,
//               //clipBehavior: Clip.none,
//               children: [
//                 Container(
//                   height: double.infinity,
//                   width: double.infinity,
//                   color: Colors.blue,
//                 ),
//                 // Container(
//                 //   height: double.infinity,
//                 //   width: double.infinity,
//                 //   decoration: BoxDecoration(
//                 //     color: Colors.amber,
//                 //     image: DecorationImage(
//                 //       image: AssetImage(
//                 //         "images/bg.jpeg",
//                 //       ),
//                 //       fit: BoxFit.cover,
//                 //     ),
//                 //   ),
//                 // ),
//                 // Positioned(
//                 //   bottom: -40,
//                 //   left: 0,
//                 //   right: 0,
//                 //   child: Center(
//                 //     child: Container(
//                 //       width: 80,
//                 //       height: 80,
//                 //       decoration: BoxDecoration(
//                 //         // shape: BoxShape.circle,
//                 //         border: Border.all(width: 4, color: Colors.white),
//                 //         borderRadius: BorderRadius.circular(50),
//                 //         color: Colors.red,
//                 //         image: DecorationImage(
//                 //           image: AssetImage("images/bg.jpeg"),
//                 //           fit: BoxFit.cover,
//                 //         ),
//                 //       ),
//                 //     ),
//                 //   ),
//                 // )
//
//                 // Container(
//                 //   height: 100,
//                 //   width: 100,
//                 //   alignment: Alignment.center,
//                 //   decoration: BoxDecoration(
//                 //     color: Colors.red,
//                 //     shape: BoxShape.circle,
//                 //   ),
//                 //   child: Text(
//                 //     "Demo",
//                 //     style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                 //   ),
//                 // ),
//
//                 Positioned(
//                   top: 20,
//                   left: 0,
//                   right: 0,
//                   child: Container(
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.white,
//                           blurRadius: 10,
//                         ),
//                       ],
//                     ),
//                     child: CircleAvatar(
//                       radius: 30,
//                     ),
//                   ),
//                 ),
//                 Positioned(
//                   left: 0,
//                   top: 100,
//                   right: 0,
//                   child: ClipOval(
//                     child: Image.asset(
//                       "images/bg.jpeg",
//                       height: 100,
//                       width: 100,
//                     ),
//                   ),
//                 ),
//
//                 Positioned(
//                   bottom: 0,
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.circular(50),
//                     child: Container(
//                       child: Image.asset(
//                         "images/bg.jpeg",
//                         height: 100,
//                         width: 100,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         )),
//   );
// }

void main() {
  runApp(MyApp());
}

import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print("MyAppBuildMethod:");
    return MaterialApp(
      title: "Day 8",
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //  leading: Icon(Icons.menu),
        title: Text("Home Page"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text("Product List"),
            SizedBox(height: 20),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
            _productCard(),
          ],
        ),
      ),
    );
  }

  // Widget _showMyName() {
  //   return Container(
  //     height: 100,
  //     width: 100,
  //     color: Colors.red,
  //   );
  // }

  Widget _productCard() => Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(width: 5),
              Container(
                width: 100,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image(
                    image: AssetImage("images/bg.jpeg"),
                  ),
                ),
              ),
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Flutter Books",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "Description of Book of Flutter and have good contents."
                        .substring(0, 30),
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        height: 20,
                        width: 40,
                        color: Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Container(
                        height: 20,
                        width: 40,
                        color: Colors.blueGrey,
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Rs.250",
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
